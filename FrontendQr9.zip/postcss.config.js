module.exports = {
  plugins: {
    'postcss-import': {},
    'tailwindcss/nesting': {},
    '@tailwindcss/postcss': {}, // Add this line
    'tailwindcss': {},
    'autoprefixer': {},
  }
}
